#ifndef ENUM_
#define ENUM_

enum CargoEmpleado {Administracion, Limpieza, Recepcion, Infraestructura};

enum EstadoReserva {Abierta, Cerrada, Cancelada};

#endif